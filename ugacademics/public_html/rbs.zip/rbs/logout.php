<?php
session_start(); 
session_destroy();
?>
<div style="text-align:center;">
<b><a href="index.php" >Back to Homepage</a></b>

</div>