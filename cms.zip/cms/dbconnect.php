<?php
$dbuser = 'ugacademics';
$dbpassword = 'ug_acads';
$dbname = 'ugacademics';
$dbhost = 'localhost';
?>
